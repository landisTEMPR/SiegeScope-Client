package parser

import (
	"log"
	"os"
	"path/filepath"
	"sort"
	"time"

	"r6-replay-recorder/database"
	"r6-replay-recorder/models"

	"github.com/redraskal/r6-dissect/dissect"
)

// Parser handles reading .rec files and storing them in the database
type Parser struct {
	db *database.Database
}

// New creates a new parser instance
func New(db *database.Database) *Parser {
	return &Parser{db: db}
}

// ImportMatch imports a match folder (containing multiple .rec files) into the database
func (p *Parser) ImportMatch(matchFolderPath string) (*models.Match, error) {
	// Open the match folder
	folder, err := os.Open(matchFolderPath)
	if err != nil {
		return nil, err
	}
	defer folder.Close()

	// Create match reader
	matchReader, err := dissect.NewMatchReader(folder)
	if err != nil {
		return nil, err
	}

	// Get the first round to access header info
	firstRound, err := matchReader.FirstRound()
	if err != nil {
		return nil, err
	}

	// Read the first round fully
	if err := firstRound.Read(); !dissect.Ok(err) {
		return nil, err
	}

	header := firstRound.Header

	// Check if match already exists
	exists, err := p.db.MatchExists(header.MatchID)
	if err != nil {
		return nil, err
	}
	if exists {
		return nil, nil // Already imported
	}

	// Calculate final scores and winner from all rounds
	teamScore, opponentScore, won := p.calculateFinalScore(matchFolderPath)

	// Create match record
	match := &models.Match{
		MatchID:         header.MatchID,
		GameVersion:     header.GameVersion,
		CodeVersion:     header.CodeVersion,
		Timestamp:       header.Timestamp,
		MatchType:       matchTypeToString(header.MatchType),
		GameMode:        header.GameMode.String(),
		Map:             header.Map.String(),
		RecordingPlayer: header.RecordingPlayer().Username,
		ProfileID:       header.RecordingProfileID,
		TeamScore:       teamScore,
		OpponentScore:   opponentScore,
		Won:             won,
		RoundsPlayed:    matchReader.NumRounds(),
		FilePath:        matchFolderPath,
	}

	// Insert match
	matchDBID, err := p.db.InsertMatch(match)
	if err != nil {
		return nil, err
	}
	match.ID = matchDBID

	// Import all rounds
	if err := p.importRounds(matchFolderPath, matchDBID); err != nil {
		// Rollback by deleting the match
		p.db.DeleteMatch(matchDBID)
		return nil, err
	}

	return match, nil
}

// ImportSingleRound imports just a single .rec file
func (p *Parser) ImportSingleRound(recFilePath string) (*models.Match, error) {
	f, err := os.Open(recFilePath)
	if err != nil {
		return nil, err
	}
	defer f.Close()

	reader, err := dissect.NewReader(f)
	if err != nil {
		return nil, err
	}

	if err := reader.Read(); !dissect.Ok(err) {
		return nil, err
	}

	header := reader.Header

	// Check if match already exists
	exists, err := p.db.MatchExists(header.MatchID)
	if err != nil {
		return nil, err
	}
	if exists {
		return nil, nil
	}

	// Determine winner from teams
	var teamScore, opponentScore int
	var won bool
	teamScore = header.Teams[0].Score
	won = header.Teams[0].Won
	opponentScore = header.Teams[1].Score

	// Create match record
	match := &models.Match{
		MatchID:         header.MatchID,
		GameVersion:     header.GameVersion,
		CodeVersion:     header.CodeVersion,
		Timestamp:       header.Timestamp,
		MatchType:       matchTypeToString(header.MatchType),
		GameMode:        header.GameMode.String(),
		Map:             header.Map.String(),
		RecordingPlayer: header.RecordingPlayer().Username,
		ProfileID:       header.RecordingProfileID,
		TeamScore:       teamScore,
		OpponentScore:   opponentScore,
		Won:             won,
		RoundsPlayed:    1,
		FilePath:        recFilePath,
	}

	matchDBID, err := p.db.InsertMatch(match)
	if err != nil {
		return nil, err
	}
	match.ID = matchDBID

	// Import the single round
	if err := p.importRoundFromReader(reader, matchDBID, 1); err != nil {
		p.db.DeleteMatch(matchDBID)
		return nil, err
	}

	return match, nil
}

func (p *Parser) calculateFinalScore(matchFolderPath string) (teamScore, opponentScore int, won bool) {
	folder, err := os.Open(matchFolderPath)
	if err != nil {
		return 0, 0, false
	}
	defer folder.Close()

	matchReader, err := dissect.NewMatchReader(folder)
	if err != nil {
		return 0, 0, false
	}

	// Get the last round for final scores
	lastRound, err := matchReader.LastRound()
	if err != nil {
		return 0, 0, false
	}

	if err := lastRound.Read(); !dissect.Ok(err) {
		return 0, 0, false
	}

	teamScore = lastRound.Header.Teams[0].Score
	won = lastRound.Header.Teams[0].Won
	opponentScore = lastRound.Header.Teams[1].Score

	return teamScore, opponentScore, won
}

func (p *Parser) importRounds(matchFolderPath string, matchDBID int64) error {
	// Read directory entries directly instead of using ListReplayFiles
	entries, err := os.ReadDir(matchFolderPath)
	if err != nil {
		log.Printf("ERROR reading directory %s: %v", matchFolderPath, err)
		return err
	}

	// Find all .rec files
	var recFiles []string
	for _, entry := range entries {
		if !entry.IsDir() && filepath.Ext(entry.Name()) == ".rec" {
			recFiles = append(recFiles, entry.Name())
		}
	}

	log.Printf("Found %d .rec files in %s", len(recFiles), matchFolderPath)

	// Sort to ensure round order
	sort.Strings(recFiles)

	for i, recFile := range recFiles {
		recPath := filepath.Join(matchFolderPath, recFile)
		log.Printf("Processing round %d: %s", i+1, recPath)

		f, err := os.Open(recPath)
		if err != nil {
			log.Printf("ERROR opening file: %v", err)
			continue
		}

		reader, err := dissect.NewReader(f)
		if err != nil {
			log.Printf("ERROR creating reader: %v", err)
			f.Close()
			continue
		}

		if err := reader.Read(); !dissect.Ok(err) {
			log.Printf("ERROR reading replay: %v", err)
			f.Close()
			continue
		}

		log.Printf("Successfully read round %d, importing...", i+1)
		if err := p.importRoundFromReader(reader, matchDBID, i+1); err != nil {
			log.Printf("ERROR importing round: %v", err)
		}
		f.Close()
	}

	return nil
}

func (p *Parser) importRoundFromReader(reader *dissect.Reader, matchDBID int64, roundNum int) error {
	header := reader.Header

	// Determine team role and win status
	var teamRole string
	var won bool
	var winCondition string
	var teamScore, opponentScore int

	team0 := header.Teams[0]
	team1 := header.Teams[1]

	teamRole = string(team0.Role)
	won = team0.Won
	if team0.Won {
		winCondition = string(team0.WinCondition)
	} else {
		winCondition = string(team1.WinCondition)
	}
	teamScore = team0.Score
	opponentScore = team1.Score

	// Create round record
	round := &models.Round{
		MatchID:       matchDBID,
		RoundNumber:   roundNum,
		Site:          header.Site,
		TeamRole:      teamRole,
		Won:           won,
		WinCondition:  winCondition,
		TeamScore:     teamScore,
		OpponentScore: opponentScore,
	}

	roundDBID, err := p.db.InsertRound(round)
	if err != nil {
		return err
	}

	// Import players
	for _, player := range header.Players {
		p.db.InsertPlayer(&models.Player{
			RoundID:   roundDBID,
			MatchID:   matchDBID,
			ProfileID: player.ProfileID,
			Username:  player.Username,
			TeamIndex: player.TeamIndex,
			Operator:  player.Operator.String(),
			Spawn:     player.Spawn,
		})
	}

	// Import match events (kills, plants, etc.)
	for _, event := range reader.MatchFeedback {
		headshot := false
		if event.Headshot != nil {
			headshot = *event.Headshot
		}

		p.db.InsertEvent(&models.MatchEvent{
			RoundID:       roundDBID,
			MatchID:       matchDBID,
			EventType:     event.Type.String(),
			Time:          event.Time,
			TimeInSeconds: int(event.TimeInSeconds),
			Username:      event.Username,
			Target:        event.Target,
			Headshot:      headshot,
		})
	}

	// Get entry kill and entry death usernames
	openingKill := reader.OpeningKill()
	openingDeath := reader.OpeningDeath()
	entryKiller := openingKill.Username
	entryDied := openingDeath.Target

	// Import player round stats
	playerStats := reader.PlayerStats()
	for _, stat := range playerStats {
		// Find the player's operator from header
		operator := ""
		teamIndex := 0
		for _, player := range header.Players {
			if player.Username == stat.Username {
				operator = player.Operator.String()
				teamIndex = player.TeamIndex
				break
			}
		}

		p.db.InsertPlayerRoundStats(&models.PlayerRoundStats{
			RoundID:            roundDBID,
			MatchID:            matchDBID,
			Username:           stat.Username,
			TeamIndex:          teamIndex,
			Operator:           operator,
			Kills:              stat.Kills,
			Died:               stat.Died,
			Assists:            stat.Assists,
			Headshots:          stat.Headshots,
			HeadshotPercentage: stat.HeadshotPercentage,
			EntryKill:          stat.Username == entryKiller,
			EntryDeath:         stat.Username == entryDied,
		})
	}

	return nil
}

// matchTypeToString converts MatchType to a readable string
func matchTypeToString(mt dissect.MatchType) string {
	switch mt {
	case dissect.QuickMatch:
		return "QuickMatch"
	case dissect.Ranked:
		return "Ranked"
	case dissect.CustomGameLocal:
		return "CustomGameLocal"
	case dissect.CustomGameOnline:
		return "CustomGameOnline"
	case dissect.Standard:
		return "Standard"
	default:
		return "Unknown"
	}
}

// FindReplayFolders scans a directory for R6 replay match folders
func (p *Parser) FindReplayFolders(rootPath string) ([]string, error) {
	var folders []string

	entries, err := os.ReadDir(rootPath)
	if err != nil {
		return nil, err
	}

	for _, entry := range entries {
		if entry.IsDir() && isMatchFolder(entry.Name()) {
			fullPath := filepath.Join(rootPath, entry.Name())
			folders = append(folders, fullPath)
		}
	}

	return folders, nil
}

// isMatchFolder checks if a folder name looks like an R6 match folder
func isMatchFolder(name string) bool {
	// R6 match folders typically start with "Match-"
	return len(name) > 6 && name[:6] == "Match-"
}

// GetDefaultReplayPath returns the default R6 replay location for the current OS
func GetDefaultReplayPath() string {
	home, err := os.UserHomeDir()
	if err != nil {
		return ""
	}

	// Default Windows path for R6 replays
	return filepath.Join(home, "Documents", "My Games", "Rainbow Six - Siege", "replays")
}

// WatchFolder watches a folder for new replay files (simplified polling version)
type FolderWatcher struct {
	path     string
	parser   *Parser
	stopChan chan struct{}
	interval time.Duration
}

// NewFolderWatcher creates a new folder watcher
func NewFolderWatcher(path string, parser *Parser, interval time.Duration) *FolderWatcher {
	return &FolderWatcher{
		path:     path,
		parser:   parser,
		stopChan: make(chan struct{}),
		interval: interval,
	}
}

// Start begins watching for new replays
func (fw *FolderWatcher) Start(onNewMatch func(*models.Match)) {
	go func() {
		ticker := time.NewTicker(fw.interval)
		defer ticker.Stop()

		for {
			select {
			case <-fw.stopChan:
				return
			case <-ticker.C:
				folders, err := fw.parser.FindReplayFolders(fw.path)
				if err != nil {
					continue
				}

				for _, folder := range folders {
					match, err := fw.parser.ImportMatch(folder)
					if err == nil && match != nil {
						onNewMatch(match)
					}
				}
			}
		}
	}()
}

// Stop stops watching
func (fw *FolderWatcher) Stop() {
	close(fw.stopChan)
}
