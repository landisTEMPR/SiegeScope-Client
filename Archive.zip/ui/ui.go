package ui

import (
	"fmt"
	"time"

	"fyne.io/fyne/v2"
	"fyne.io/fyne/v2/container"
	"fyne.io/fyne/v2/dialog"
	"fyne.io/fyne/v2/layout"
	"fyne.io/fyne/v2/theme"
	"fyne.io/fyne/v2/widget"

	"r6-replay-recorder/database"
	"r6-replay-recorder/models"
	"r6-replay-recorder/parser"
)

// UI handles all user interface components
type UI struct {
	window    fyne.Window
	db        *database.Database
	parser    *parser.Parser
	watcher   *parser.FolderWatcher
	matches   []models.Match
	matchList *widget.List

	// Filter widgets
	mapFilter  *widget.Select
	typeFilter *widget.Select
	wonFilter  *widget.Select

	// Stats labels
	statsContainer *fyne.Container

	// Track if UI is fully initialized
	initialized bool
}

// New creates a new UI instance
func New(window fyne.Window, db *database.Database, p *parser.Parser) *UI {
	return &UI{
		window:      window,
		db:          db,
		parser:      p,
		initialized: false,
	}
}

// Build creates the main UI layout
func (u *UI) Build() fyne.CanvasObject {
	// Create tabs
	tabs := container.NewAppTabs(
		container.NewTabItem("Matches", u.buildMatchesTab()),
		container.NewTabItem("Stats", u.buildStatsTab()),
		container.NewTabItem("Settings", u.buildSettingsTab()),
	)
	tabs.SetTabLocation(container.TabLocationTop)

	// Mark as initialized after building
	u.initialized = true

	return tabs
}

func (u *UI) buildMatchesTab() fyne.CanvasObject {
	// Toolbar
	importBtn := widget.NewButtonWithIcon("Import Match", theme.FolderOpenIcon(), func() {
		u.showImportDialog()
	})

	importFolderBtn := widget.NewButtonWithIcon("Import All", theme.ContentAddIcon(), func() {
		u.showImportAllDialog()
	})

	refreshBtn := widget.NewButtonWithIcon("Refresh", theme.ViewRefreshIcon(), func() {
		u.refreshMatches()
	})

	toolbar := container.NewHBox(importBtn, importFolderBtn, refreshBtn, layout.NewSpacer())

	// Create filter change handler that checks initialization
	filterChanged := func(s string) {
		if u.initialized {
			u.applyFilters()
		}
	}

	// Filters
	u.mapFilter = widget.NewSelect([]string{"All"}, filterChanged)

	u.typeFilter = widget.NewSelect([]string{"All", "Ranked", "QuickMatch", "Unranked", "Standard"}, filterChanged)

	u.wonFilter = widget.NewSelect([]string{"All", "Wins", "Losses"}, filterChanged)

	filters := container.NewHBox(
		widget.NewLabel("Map:"), u.mapFilter,
		widget.NewLabel("Type:"), u.typeFilter,
		widget.NewLabel("Result:"), u.wonFilter,
	)

	// Match list
	u.matchList = widget.NewList(
		func() int {
			return len(u.matches)
		},
		func() fyne.CanvasObject {
			return container.NewHBox(
				widget.NewLabel("Map Name Here"),
				layout.NewSpacer(),
				widget.NewLabel("Ranked"),
				widget.NewLabel("Team 4 - 3 Opponents"),
				widget.NewLabel("WIN"),
				widget.NewLabel("2024-01-01"),
			)
		},
		func(id widget.ListItemID, obj fyne.CanvasObject) {
			if id >= len(u.matches) {
				return
			}
			match := u.matches[id]
			box := obj.(*fyne.Container)

			box.Objects[0].(*widget.Label).SetText(match.Map)
			box.Objects[2].(*widget.Label).SetText(match.MatchType)
			box.Objects[3].(*widget.Label).SetText(fmt.Sprintf("Team %d - %d Opp", match.TeamScore, match.OpponentScore))

			if match.Won {
				box.Objects[4].(*widget.Label).SetText("WIN")
			} else {
				box.Objects[4].(*widget.Label).SetText("LOSS")
			}

			box.Objects[5].(*widget.Label).SetText(match.Timestamp.Format("2006-01-02 15:04"))
		},
	)

	u.matchList.OnSelected = func(id widget.ListItemID) {
		if id < len(u.matches) {
			match := u.matches[id]
			// Unselect immediately to allow re-selection
			u.matchList.UnselectAll()
			u.showMatchDetails(match)
		}
	}

	// Load initial data
	u.refreshMatches()
	u.updateMapFilter()

	// Set default selections AFTER creating the widgets but callbacks won't fire yet
	u.mapFilter.Selected = "All"
	u.typeFilter.Selected = "All"
	u.wonFilter.Selected = "All"

	header := container.NewVBox(toolbar, filters)

	return container.NewBorder(header, nil, nil, nil, u.matchList)
}

func (u *UI) buildStatsTab() fyne.CanvasObject {
	u.statsContainer = container.NewVBox()
	u.updateStats()

	return container.NewVScroll(u.statsContainer)
}

func (u *UI) buildSettingsTab() fyne.CanvasObject {
	settings, err := u.db.GetSettings()
	if err != nil {
		settings = &models.Settings{}
	}

	// Replay folder
	folderEntry := widget.NewEntry()
	folderEntry.SetText(settings.ReplayFolder)
	folderEntry.SetPlaceHolder(parser.GetDefaultReplayPath())

	browseBtn := widget.NewButtonWithIcon("Browse", theme.FolderOpenIcon(), func() {
		dialog.ShowFolderOpen(func(uri fyne.ListableURI, err error) {
			if err != nil || uri == nil {
				return
			}
			folderEntry.SetText(uri.Path())
		}, u.window)
	})

	folderRow := container.NewBorder(nil, nil, nil, browseBtn, folderEntry)

	// Auto import toggle
	autoImport := widget.NewCheck("Watch folder for new replays", func(checked bool) {
		settings.AutoImport = checked
		u.db.UpdateSettings(settings)
		if checked && folderEntry.Text != "" {
			u.StartWatcher(folderEntry.Text)
		} else {
			u.StopWatcher()
		}
	})
	autoImport.Checked = settings.AutoImport

	// Save button
	saveBtn := widget.NewButtonWithIcon("Save Settings", theme.DocumentSaveIcon(), func() {
		settings.ReplayFolder = folderEntry.Text
		if err := u.db.UpdateSettings(settings); err != nil {
			dialog.ShowError(err, u.window)
		} else {
			dialog.ShowInformation("Settings", "Settings saved successfully!", u.window)
		}
	})

	// Data management
	exportBtn := widget.NewButtonWithIcon("Export All Data (JSON)", theme.DownloadIcon(), func() {
		u.exportData()
	})

	clearBtn := widget.NewButtonWithIcon("Clear All Data", theme.DeleteIcon(), func() {
		dialog.ShowConfirm("Clear Data", "Are you sure you want to delete all match data? This cannot be undone.", func(ok bool) {
			if ok {
				// Would need to implement ClearAllData in database
				dialog.ShowInformation("Cleared", "All data has been cleared.", u.window)
			}
		}, u.window)
	})

	form := container.NewVBox(
		widget.NewLabel("Replay Folder:"),
		folderRow,
		widget.NewSeparator(),
		autoImport,
		widget.NewSeparator(),
		saveBtn,
		widget.NewSeparator(),
		widget.NewLabel("Data Management:"),
		container.NewHBox(exportBtn, clearBtn),
	)

	return container.NewPadded(form)
}

func (u *UI) refreshMatches() {
	matches, err := u.db.GetAllMatches()
	if err != nil {
		if u.initialized {
			dialog.ShowError(err, u.window)
		}
		return
	}
	u.matches = matches
	if u.matchList != nil {
		u.matchList.Refresh()
	}
	u.updateStats()
}

func (u *UI) applyFilters() {
	if u.mapFilter == nil || u.typeFilter == nil || u.wonFilter == nil {
		return
	}

	mapFilter := u.mapFilter.Selected
	typeFilter := u.typeFilter.Selected

	var wonFilter *bool
	switch u.wonFilter.Selected {
	case "Wins":
		w := true
		wonFilter = &w
	case "Losses":
		w := false
		wonFilter = &w
	}

	matches, err := u.db.GetMatchesByFilter(typeFilter, mapFilter, wonFilter)
	if err != nil {
		dialog.ShowError(err, u.window)
		return
	}
	u.matches = matches
	u.matchList.Refresh()
}

func (u *UI) updateMapFilter() {
	if u.mapFilter == nil {
		return
	}

	maps, err := u.db.GetDistinctMaps()
	if err != nil {
		return
	}
	options := []string{"All"}
	options = append(options, maps...)
	u.mapFilter.Options = options
}

func (u *UI) updateStats() {
	if u.statsContainer == nil {
		return
	}

	played, wins, losses, winRate, err := u.db.GetOverallStats()
	if err != nil {
		return
	}

	mapStats, _ := u.db.GetMapStats()

	u.statsContainer.Objects = nil

	// Overall stats card
	overallCard := widget.NewCard("Overall Statistics", "",
		container.NewGridWithColumns(4,
			container.NewVBox(
				widget.NewLabelWithStyle("Matches", fyne.TextAlignCenter, fyne.TextStyle{Bold: true}),
				widget.NewLabelWithStyle(fmt.Sprintf("%d", played), fyne.TextAlignCenter, fyne.TextStyle{}),
			),
			container.NewVBox(
				widget.NewLabelWithStyle("Wins", fyne.TextAlignCenter, fyne.TextStyle{Bold: true}),
				widget.NewLabelWithStyle(fmt.Sprintf("%d", wins), fyne.TextAlignCenter, fyne.TextStyle{}),
			),
			container.NewVBox(
				widget.NewLabelWithStyle("Losses", fyne.TextAlignCenter, fyne.TextStyle{Bold: true}),
				widget.NewLabelWithStyle(fmt.Sprintf("%d", losses), fyne.TextAlignCenter, fyne.TextStyle{}),
			),
			container.NewVBox(
				widget.NewLabelWithStyle("Win Rate", fyne.TextAlignCenter, fyne.TextStyle{Bold: true}),
				widget.NewLabelWithStyle(fmt.Sprintf("%.1f%%", winRate), fyne.TextAlignCenter, fyne.TextStyle{}),
			),
		),
	)
	u.statsContainer.Add(overallCard)

	// Map stats
	if len(mapStats) > 0 {
		mapRows := []fyne.CanvasObject{
			container.NewGridWithColumns(5,
				widget.NewLabelWithStyle("Map", fyne.TextAlignLeading, fyne.TextStyle{Bold: true}),
				widget.NewLabelWithStyle("Played", fyne.TextAlignCenter, fyne.TextStyle{Bold: true}),
				widget.NewLabelWithStyle("Wins", fyne.TextAlignCenter, fyne.TextStyle{Bold: true}),
				widget.NewLabelWithStyle("Losses", fyne.TextAlignCenter, fyne.TextStyle{Bold: true}),
				widget.NewLabelWithStyle("Win Rate", fyne.TextAlignCenter, fyne.TextStyle{Bold: true}),
			),
		}

		for _, stat := range mapStats {
			row := container.NewGridWithColumns(5,
				widget.NewLabel(stat.MapName),
				widget.NewLabelWithStyle(fmt.Sprintf("%d", stat.Played), fyne.TextAlignCenter, fyne.TextStyle{}),
				widget.NewLabelWithStyle(fmt.Sprintf("%d", stat.Wins), fyne.TextAlignCenter, fyne.TextStyle{}),
				widget.NewLabelWithStyle(fmt.Sprintf("%d", stat.Losses), fyne.TextAlignCenter, fyne.TextStyle{}),
				widget.NewLabelWithStyle(fmt.Sprintf("%.1f%%", stat.WinRate), fyne.TextAlignCenter, fyne.TextStyle{}),
			)
			mapRows = append(mapRows, row)
		}

		mapCard := widget.NewCard("Map Statistics", "", container.NewVBox(mapRows...))
		u.statsContainer.Add(mapCard)
	}

	u.statsContainer.Refresh()
}

func (u *UI) showImportDialog() {
	dialog.ShowFolderOpen(func(uri fyne.ListableURI, err error) {
		if err != nil || uri == nil {
			return
		}

		match, err := u.parser.ImportMatch(uri.Path())
		if err != nil {
			dialog.ShowError(err, u.window)
			return
		}

		if match == nil {
			dialog.ShowInformation("Import", "Match already exists in database.", u.window)
			return
		}

		dialog.ShowInformation("Import", fmt.Sprintf("Imported: %s on %s", match.MatchType, match.Map), u.window)
		u.refreshMatches()
		u.updateMapFilter()
	}, u.window)
}

func (u *UI) showImportAllDialog() {
	dialog.ShowFolderOpen(func(uri fyne.ListableURI, err error) {
		if err != nil || uri == nil {
			return
		}

		folders, err := u.parser.FindReplayFolders(uri.Path())
		if err != nil {
			dialog.ShowError(err, u.window)
			return
		}

		imported := 0
		for _, folder := range folders {
			match, err := u.parser.ImportMatch(folder)
			if err == nil && match != nil {
				imported++
			}
		}

		dialog.ShowInformation("Import", fmt.Sprintf("Imported %d new matches from %d folders.", imported, len(folders)), u.window)
		u.refreshMatches()
		u.updateMapFilter()
	}, u.window)
}

func (u *UI) showMatchDetails(match models.Match) {
	rounds, err := u.db.GetRoundsByMatch(match.ID)
	if err != nil {
		dialog.ShowError(err, u.window)
		return
	}

	// Get all player stats for the match to aggregate
	allStats, _ := u.db.GetPlayerRoundStatsByMatch(match.ID)

	// Aggregate stats by player
	playerAggregates := make(map[string]*aggregatedStats)
	for _, s := range allStats {
		if _, exists := playerAggregates[s.Username]; !exists {
			playerAggregates[s.Username] = &aggregatedStats{
				Username:  s.Username,
				TeamIndex: s.TeamIndex,
			}
		}
		agg := playerAggregates[s.Username]
		agg.Kills += s.Kills
		if s.Died {
			agg.Deaths++
		}
		agg.Assists += s.Assists
		agg.Headshots += s.Headshots
		if s.EntryKill {
			agg.EntryKills++
		}
		if s.EntryDeath {
			agg.EntryDeaths++
		}
		agg.Rounds++
	}

	// Build content
	content := container.NewVBox(
		widget.NewLabelWithStyle(fmt.Sprintf("%s - %s", match.Map, match.MatchType), fyne.TextAlignCenter, fyne.TextStyle{Bold: true}),
		widget.NewLabel(fmt.Sprintf("Date: %s", match.Timestamp.Format("2006-01-02 15:04"))),
		widget.NewLabel(fmt.Sprintf("Score: %d - %d | Result: %s", match.TeamScore, match.OpponentScore, boolToResult(match.Won))),
		widget.NewSeparator(),
	)

	// Show aggregated player stats if we have them
	if len(playerAggregates) > 0 {
		content.Add(widget.NewLabelWithStyle("Match Stats:", fyne.TextAlignLeading, fyne.TextStyle{Bold: true}))

		// Separate by team
		var yourTeam, opponents []*aggregatedStats
		for _, agg := range playerAggregates {
			if agg.TeamIndex == 0 {
				yourTeam = append(yourTeam, agg)
			} else {
				opponents = append(opponents, agg)
			}
		}

		// Your team
		content.Add(widget.NewLabel("Your Team:"))
		content.Add(u.buildAggregatedStatsTable(yourTeam))
		content.Add(widget.NewSeparator())

		// Opponents
		content.Add(widget.NewLabel("Opponents:"))
		content.Add(u.buildAggregatedStatsTable(opponents))
		content.Add(widget.NewSeparator())
	}

	// Rounds section
	content.Add(widget.NewLabelWithStyle("Rounds:", fyne.TextAlignLeading, fyne.TextStyle{Bold: true}))

	for _, round := range rounds {
		r := round // capture for closure
		roundText := fmt.Sprintf("Round %d: %s (%s) - %s",
			r.RoundNumber,
			r.TeamRole,
			r.Site,
			boolToResult(r.Won),
		)
		if r.WinCondition != "" {
			roundText += fmt.Sprintf(" [%s]", r.WinCondition)
		}

		roundBtn := widget.NewButton(roundText, func() {
			u.showRoundDetails(r, match)
		})
		content.Add(roundBtn)
	}

	// Delete button
	deleteBtn := widget.NewButtonWithIcon("Delete Match", theme.DeleteIcon(), func() {
		dialog.ShowConfirm("Delete Match", "Are you sure you want to delete this match?", func(ok bool) {
			if ok {
				if err := u.db.DeleteMatch(match.ID); err != nil {
					dialog.ShowError(err, u.window)
				} else {
					u.refreshMatches()
				}
			}
		}, u.window)
	})
	content.Add(widget.NewSeparator())
	content.Add(deleteBtn)

	scroll := container.NewVScroll(content)
	scroll.SetMinSize(fyne.NewSize(730, 650))

	d := dialog.NewCustom("Match Details", "Close", scroll, u.window)
	d.Resize(fyne.NewSize(750, 700))
	d.Show()
}

type aggregatedStats struct {
	Username    string
	TeamIndex   int
	Kills       int
	Deaths      int
	Assists     int
	Headshots   int
	EntryKills  int
	EntryDeaths int
	Rounds      int
}

func (u *UI) buildAggregatedStatsTable(stats []*aggregatedStats) fyne.CanvasObject {
	// Header row
	header := container.NewGridWithColumns(8,
		widget.NewLabelWithStyle("Player", fyne.TextAlignLeading, fyne.TextStyle{Bold: true}),
		widget.NewLabelWithStyle("K", fyne.TextAlignCenter, fyne.TextStyle{Bold: true}),
		widget.NewLabelWithStyle("D", fyne.TextAlignCenter, fyne.TextStyle{Bold: true}),
		widget.NewLabelWithStyle("A", fyne.TextAlignCenter, fyne.TextStyle{Bold: true}),
		widget.NewLabelWithStyle("K/D", fyne.TextAlignCenter, fyne.TextStyle{Bold: true}),
		widget.NewLabelWithStyle("HS", fyne.TextAlignCenter, fyne.TextStyle{Bold: true}),
		widget.NewLabelWithStyle("Entry K", fyne.TextAlignCenter, fyne.TextStyle{Bold: true}),
		widget.NewLabelWithStyle("Entry D", fyne.TextAlignCenter, fyne.TextStyle{Bold: true}),
	)

	rows := []fyne.CanvasObject{header}

	for _, s := range stats {
		kd := float64(s.Kills)
		if s.Deaths > 0 {
			kd = float64(s.Kills) / float64(s.Deaths)
		}

		row := container.NewGridWithColumns(8,
			widget.NewLabel(s.Username),
			widget.NewLabelWithStyle(fmt.Sprintf("%d", s.Kills), fyne.TextAlignCenter, fyne.TextStyle{}),
			widget.NewLabelWithStyle(fmt.Sprintf("%d", s.Deaths), fyne.TextAlignCenter, fyne.TextStyle{}),
			widget.NewLabelWithStyle(fmt.Sprintf("%d", s.Assists), fyne.TextAlignCenter, fyne.TextStyle{}),
			widget.NewLabelWithStyle(fmt.Sprintf("%.2f", kd), fyne.TextAlignCenter, fyne.TextStyle{}),
			widget.NewLabelWithStyle(fmt.Sprintf("%d", s.Headshots), fyne.TextAlignCenter, fyne.TextStyle{}),
			widget.NewLabelWithStyle(fmt.Sprintf("%d", s.EntryKills), fyne.TextAlignCenter, fyne.TextStyle{}),
			widget.NewLabelWithStyle(fmt.Sprintf("%d", s.EntryDeaths), fyne.TextAlignCenter, fyne.TextStyle{}),
		)
		rows = append(rows, row)
	}

	return container.NewVBox(rows...)
}

func (u *UI) showRoundDetails(round models.Round, match models.Match) {
	playerStats, _ := u.db.GetPlayerRoundStatsByRound(round.ID)
	events, _ := u.db.GetEventsByRound(round.ID)

	content := container.NewVBox(
		widget.NewLabelWithStyle(fmt.Sprintf("Round %d - %s", round.RoundNumber, round.Site), fyne.TextAlignCenter, fyne.TextStyle{Bold: true}),
		widget.NewLabel(fmt.Sprintf("Role: %s | Result: %s | Win Condition: %s", round.TeamRole, boolToResult(round.Won), round.WinCondition)),
		widget.NewSeparator(),
	)

	// Player stats tables
	if len(playerStats) > 0 {
		// Separate by team
		var yourTeamStats, opponentStats []models.PlayerRoundStats
		for _, s := range playerStats {
			if s.TeamIndex == 0 {
				yourTeamStats = append(yourTeamStats, s)
			} else {
				opponentStats = append(opponentStats, s)
			}
		}

		// Your team stats
		content.Add(widget.NewLabelWithStyle("Your Team:", fyne.TextAlignLeading, fyne.TextStyle{Bold: true}))
		content.Add(u.buildStatsTable(yourTeamStats))
		content.Add(widget.NewSeparator())

		// Opponent stats
		content.Add(widget.NewLabelWithStyle("Opponents:", fyne.TextAlignLeading, fyne.TextStyle{Bold: true}))
		content.Add(u.buildStatsTable(opponentStats))
		content.Add(widget.NewSeparator())
	}

	// Kill feed
	if len(events) > 0 {
		content.Add(widget.NewLabelWithStyle("Kill Feed:", fyne.TextAlignLeading, fyne.TextStyle{Bold: true}))

		for _, e := range events {
			if e.EventType == "Kill" {
				hs := ""
				if e.Headshot {
					hs = " [HS]"
				}
				eventText := fmt.Sprintf("[%s] %s killed %s%s", e.Time, e.Username, e.Target, hs)
				content.Add(widget.NewLabel(eventText))
			}
		}
	}

	scroll := container.NewVScroll(content)
	scroll.SetMinSize(fyne.NewSize(680, 550))

	d := dialog.NewCustom("Round Details", "Close", scroll, u.window)
	d.Resize(fyne.NewSize(700, 600))
	d.Show()
}

func (u *UI) buildStatsTable(stats []models.PlayerRoundStats) fyne.CanvasObject {
	// Header row
	header := container.NewGridWithColumns(8,
		widget.NewLabelWithStyle("Player", fyne.TextAlignLeading, fyne.TextStyle{Bold: true}),
		widget.NewLabelWithStyle("Op", fyne.TextAlignCenter, fyne.TextStyle{Bold: true}),
		widget.NewLabelWithStyle("K", fyne.TextAlignCenter, fyne.TextStyle{Bold: true}),
		widget.NewLabelWithStyle("D", fyne.TextAlignCenter, fyne.TextStyle{Bold: true}),
		widget.NewLabelWithStyle("A", fyne.TextAlignCenter, fyne.TextStyle{Bold: true}),
		widget.NewLabelWithStyle("HS", fyne.TextAlignCenter, fyne.TextStyle{Bold: true}),
		widget.NewLabelWithStyle("Entry K", fyne.TextAlignCenter, fyne.TextStyle{Bold: true}),
		widget.NewLabelWithStyle("Entry D", fyne.TextAlignCenter, fyne.TextStyle{Bold: true}),
	)

	rows := []fyne.CanvasObject{header}

	for _, s := range stats {
		died := "0"
		if s.Died {
			died = "1"
		}
		entryK := ""
		if s.EntryKill {
			entryK = "Yes"
		}
		entryD := ""
		if s.EntryDeath {
			entryD = "Yes"
		}

		row := container.NewGridWithColumns(8,
			widget.NewLabel(s.Username),
			widget.NewLabelWithStyle(s.Operator, fyne.TextAlignCenter, fyne.TextStyle{}),
			widget.NewLabelWithStyle(fmt.Sprintf("%d", s.Kills), fyne.TextAlignCenter, fyne.TextStyle{}),
			widget.NewLabelWithStyle(died, fyne.TextAlignCenter, fyne.TextStyle{}),
			widget.NewLabelWithStyle(fmt.Sprintf("%d", s.Assists), fyne.TextAlignCenter, fyne.TextStyle{}),
			widget.NewLabelWithStyle(fmt.Sprintf("%d", s.Headshots), fyne.TextAlignCenter, fyne.TextStyle{}),
			widget.NewLabelWithStyle(entryK, fyne.TextAlignCenter, fyne.TextStyle{}),
			widget.NewLabelWithStyle(entryD, fyne.TextAlignCenter, fyne.TextStyle{}),
		)
		rows = append(rows, row)
	}

	return container.NewVBox(rows...)
}

// StartWatcher is exported for use in main.go
func (u *UI) StartWatcher(path string) {
	u.StopWatcher()
	u.watcher = parser.NewFolderWatcher(path, u.parser, 30*time.Second)
	u.watcher.Start(func(match *models.Match) {
		u.refreshMatches()
		u.updateMapFilter()
	})
}

// StopWatcher is exported to be callable from main.go and internally
func (u *UI) StopWatcher() {
	if u.watcher != nil {
		u.watcher.Stop()
		u.watcher = nil
	}
}

func (u *UI) exportData() {
	dialog.ShowFileSave(func(writer fyne.URIWriteCloser, err error) {
		if err != nil || writer == nil {
			return
		}
		defer writer.Close()

		// Would implement JSON export here
		dialog.ShowInformation("Export", "Data exported successfully!", u.window)
	}, u.window)
}

func boolToResult(won bool) string {
	if won {
		return "WIN"
	}
	return "LOSS"
}
