package models

import "time"

// Match represents a complete match with all rounds
type Match struct {
	ID              int64     `json:"id"`
	MatchID         string    `json:"matchId"`         // Game's internal match ID
	GameVersion     string    `json:"gameVersion"`     // e.g., "Y8S1"
	CodeVersion     int       `json:"codeVersion"`     // e.g., 7422506
	Timestamp       time.Time `json:"timestamp"`       // When the match was played
	MatchType       string    `json:"matchType"`       // Ranked, QuickMatch, etc.
	GameMode        string    `json:"gameMode"`        // Bomb, Secure Area, Hostage
	Map             string    `json:"map"`             // Villa, House, etc.
	RecordingPlayer string    `json:"recordingPlayer"` // Who recorded this replay
	ProfileID       string    `json:"profileId"`       // Ubisoft profile ID
	TeamScore       int       `json:"teamScore"`       // Your team's final score
	OpponentScore   int       `json:"opponentScore"`   // Opponent's final score
	Won             bool      `json:"won"`             // Did you win?
	RoundsPlayed    int       `json:"roundsPlayed"`    // Total rounds
	ImportedAt      time.Time `json:"importedAt"`      // When imported to app
	FilePath        string    `json:"filePath"`        // Path to original .rec folder
}

// Round represents a single round within a match
type Round struct {
	ID            int64  `json:"id"`
	MatchID       int64  `json:"matchId"`       // Foreign key to Match
	RoundNumber   int    `json:"roundNumber"`   // 1, 2, 3...
	Site          string `json:"site"`          // Defense site
	TeamRole      string `json:"teamRole"`      // Attack or Defense
	Won           bool   `json:"won"`           // Did your team win this round?
	WinCondition  string `json:"winCondition"`  // KilledOpponents, BombDetonated, etc.
	TeamScore     int    `json:"teamScore"`     // Score after this round
	OpponentScore int    `json:"opponentScore"` // Opponent score after this round
}

// Player represents a player in a round
type Player struct {
	ID        int64  `json:"id"`
	RoundID   int64  `json:"roundId"`   // Foreign key to Round
	MatchID   int64  `json:"matchId"`   // Foreign key to Match
	ProfileID string `json:"profileId"` // Ubisoft profile ID
	Username  string `json:"username"`
	TeamIndex int    `json:"teamIndex"` // 0 = your team, 1 = opponents
	Operator  string `json:"operator"`  // Operator name
	Spawn     string `json:"spawn"`     // Spawn location
}

// MatchEvent represents a kill, plant, disable, etc.
type MatchEvent struct {
	ID            int64  `json:"id"`
	RoundID       int64  `json:"roundId"`
	MatchID       int64  `json:"matchId"`
	EventType     string `json:"eventType"`     // Kill, DefuserPlant, DefuserDisable, etc.
	Time          string `json:"time"`          // "2:45" format
	TimeInSeconds int    `json:"timeInSeconds"` // 165
	Username      string `json:"username"`      // Who did it
	Target        string `json:"target"`        // Who was killed (for kills)
	Headshot      bool   `json:"headshot"`      // Was it a headshot?
	Message       string `json:"message"`       // Additional info
}

// PlayerRoundStats represents a player's stats for a single round
type PlayerRoundStats struct {
	ID                 int64   `json:"id"`
	RoundID            int64   `json:"roundId"`
	MatchID            int64   `json:"matchId"`
	Username           string  `json:"username"`
	TeamIndex          int     `json:"teamIndex"`
	Operator           string  `json:"operator"`
	Kills              int     `json:"kills"`
	Died               bool    `json:"died"`
	Assists            int     `json:"assists"`
	Headshots          int     `json:"headshots"`
	HeadshotPercentage float64 `json:"headshotPercentage"`
	EntryKill          bool    `json:"entryKill"`  // Got the first kill of the round
	EntryDeath         bool    `json:"entryDeath"` // Was the first death of the round
}

// PlayerStats aggregated stats for a player across matches
type PlayerStats struct {
	ProfileID          string  `json:"profileId"`
	Username           string  `json:"username"`
	MatchesPlayed      int     `json:"matchesPlayed"`
	RoundsPlayed       int     `json:"roundsPlayed"`
	Kills              int     `json:"kills"`
	Deaths             int     `json:"deaths"`
	Assists            int     `json:"assists"`
	Headshots          int     `json:"headshots"`
	HeadshotPercentage float64 `json:"headshotPercentage"`
	KD                 float64 `json:"kd"`
	WinRate            float64 `json:"winRate"`
}

// MapStats aggregated stats for a specific map
type MapStats struct {
	MapName   string  `json:"mapName"`
	Played    int     `json:"played"`
	Wins      int     `json:"wins"`
	Losses    int     `json:"losses"`
	WinRate   float64 `json:"winRate"`
	AvgRounds float64 `json:"avgRounds"`
}

// OperatorStats aggregated stats for an operator
type OperatorStats struct {
	Operator   string  `json:"operator"`
	TimesUsed  int     `json:"timesUsed"`
	Kills      int     `json:"kills"`
	Deaths     int     `json:"deaths"`
	KD         float64 `json:"kd"`
	RoundsWon  int     `json:"roundsWon"`
	RoundsLost int     `json:"roundsLost"`
	WinRate    float64 `json:"winRate"`
}

// Settings represents user application settings
type Settings struct {
	ID              int64  `json:"id"`
	ReplayFolder    string `json:"replayFolder"`    // Path to R6 replays
	AutoImport      bool   `json:"autoImport"`      // Watch folder for new replays
	Theme           string `json:"theme"`           // dark, light
	StartMinimized  bool   `json:"startMinimized"`  // Start in system tray
	StartWithSystem bool   `json:"startWithSystem"` // Launch on boot
    APIKey       string `json:"api_key"`            // Verify user subscription
}

